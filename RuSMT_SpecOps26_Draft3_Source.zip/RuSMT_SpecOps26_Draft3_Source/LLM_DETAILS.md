# RuSMT — LLM prompt and runner companion (Draft 3)

## Paper-reported setup

Source: accepted paper, §§3.3 and 6.

The proposer is gpt-5.4-mini through the Codex command-line runner. RuSMT
supplies the marker, emitted SMT-LIB context, and rejected candidates with
solver feedback. It requests one witness per marker with up to nine proposal
rounds. TOML budgets are 2 s for the unconstrained Z3 probe and 20 s for each
pinned-candidate Z3 check, not a 20 s model-generation timeout.

After an unsatisfiable candidate check, a second solver query with the input
fixed but the target assertion removed observes the returned marker. This
outcome is supplied to the next prompt. The next candidate must still satisfy
the original query, and concrete replay must reach the same marker.

## Archive-level illustration

The cached prompts below are exact records from the attached archive. They
label their SMT-LIB context as truncated. Their prompt hints emphasize that
only the first error matters, the document should be short, and the chosen
condition should be the one violated. The text response is a concrete input
between `<<<` and `>>>`, not a patch or a claimed solver verdict.

The archive runner invokes `codex exec`, selects low reasoning effort, denies
source-tree reads at the OS level, and returns its last-message text. The
framework creates a fresh working directory per invocation and supplies
per-marker history in each new prompt. These records do not establish zero
internal tool use or any causal advantage/disadvantage from these settings.

## Interpretation of results

Use the accepted paper's accounting: 146 of 183 markers reached; 37 remain
unresolved. Misses: 20 date/time/offset, 10 numeric literal, 6 table/key/composite,
and 1 array. The paper associates the pattern with earlier errors masking the
target and chains of numeric or temporal subparsers.

There are 146 accepted and 442 unsatisfiable candidate checks. Among the
rejections, 88.2% reached another marker, 5.9% were valid TOML, and 5.9% had no
diagnostic outcome. Separately, the paper reports 28 repeated candidates and
19 occasions with no parsable candidate response. It reports no acceptance-check
timeouts. No prompt-length, reasoning-effort, model-choice, or full-context
ablation is reported, so none of those is presented as the proven cause of a miss.

## Exact recorded exchanges

The files contain the prompt above `===RESPONSE===` and the final response
below it. Their contents are reproduced as source material, not rewritten
to alter the paper's claims.

### Round 1

```text
You are generating a test input inside a program-synthesis pipeline.
Object language: toml
Goal: an input whose execution reaches the error marker `array_table_missing_close_char`.

Z3 cannot search for this input: the lifted parser is too large to solve with a symbolic input. So the division of labour is inverted — YOU propose a concrete candidate, and Z3 DECIDES it by pinning it into the unmodified query. A candidate is accepted only when Z3 answers `sat`, which means the lifted semantics genuinely reach `array_table_missing_close_char` on that input.

Two things make a candidate fail, and both are reported back to you:
* `unsat` — the input does not reach `array_table_missing_close_char`. Usually it reaches a DIFFERENT error first (an earlier syntax error shadows the one you want), or it is simply valid.
* `unknown`/timeout — rare for a pinned input; treat as a hint to simplify.

== The channel (a contract, not advice) ==
A control character cannot reach us as a raw byte. Spell it `\u{XX}` — e.g. `\u{0}` for NUL, `\u{7f}` for DEL. That is the ONLY escape decoded; every other backslash is passed through verbatim, so a TOML escape such as `\q` or `\uZZZZ` reaches the parser exactly as you wrote it.

== A domain prior (hints only; ignore any that do not fit) ==
These shape where you look. They decide nothing: acceptance is Z3's alone.
* Only the FIRST error matters — the parser stops there, so everything before the intended violation must be valid or it will shadow it.
* Shorter is better: extra keys, tables and whitespace add chances to trip an earlier rule.
* The marker name states the rule. Violate exactly that and nothing else.

== The emitted SMT-LIB for this marker (truncated) ==
(set-option :print-success false)
(set-option :produce-models true)
(set-option :produce-proofs false)
(set-option :produce-unsat-cores false)
(set-option :sat.random_seed 42)
(set-option :smt.random_seed 42)

(set-option :sat.restart.max 100000)
(set-option :smt.arith.solver 6)
(set-option :smt.case_split 3)
(set-option :smt.phase_selection 3)
(set-option :smt.mbqi true)
(set-option :smt.qi.eager_threshold 10.0)
(set-option :smt.qi.max_multi_patterns 1000)
(set-option :smt.ematching true)
(set-option :smt.auto_config false)

(declare-datatypes ((RuSmtSet 1)) ((par (T) ((mk-rset (rset-data (Array T Bool)) (rset-card Int))))))
(declare-datatypes ((RuSmtArray 2)) ((par (K V) ((mk-rarr (rarr-da
; … 216260 bytes of parser definitions elided …
Ok_2_ (parse_newline state)))))) (field_ParseResult_Ok_2_ (parse_expression (field_ParseResult_Ok_2_ (parse_newline state)))))))))))))
(define-fun parse_toml_inner ((state State)) (ParseResult Value) (ite (is-ParseResult_Err (parse_expression state)) ((as ParseResult_Err (ParseResult Value)) (field_ParseResult_Err_1_ (parse_expression state))) (ite (is-ParseResult_NoMatch (parse_expression state)) (as ParseResult_NoMatch (ParseResult Value)) (ite (is-Optional_None (current_char (field_ParseResult_Ok_2_ (parse_expression state)))) ((as ParseResult_Ok (ParseResult Value)) ((as Value_Table Value) (field_ParseResult_Ok_1_ (parse_expression state))) (field_ParseResult_Ok_2_ (parse_expression state))) (parse_toml_loop (field_ParseResult_Ok_1_ (parse_expression state)) (field_ParseResult_Ok_2_ (parse_expression state)))))))
(define-fun parse_toml ((input (Seq (_ BitVec 32)))) (ParseResult Value) (parse_toml_inner (mk-State default_parser_context 0 input)))

; Base SMT-LIB definitions complete
; Add error-specific assertions below


(declare-const input_0 (Seq (_ BitVec 32)))
(assert (forall ((__i Int)) (=> (and (>= __i 0) (< __i (seq.len input_0))) (let ((__c (seq.nth input_0 __i))) (or (bvule __c #x0000D7FF) (and (bvuge __c #x0000E000) (bvule __c #x0002FFFF)))))))(assert (and (is-ParseResult_Err (parse_toml input_0)) (= (bvand (field_ParseResult_Err_1_ (parse_toml input_0)) (_ bv1125899906842624 183)) (_ bv1125899906842624 183))))
(check-sat)
(get-info :reason-unknown)
(get-model)


Reply with the candidate input between <<< and >>> and nothing else:
input <<<
(your candidate here)
>>>

===RESPONSE===
<<<
[[a
>>>
```

### Round 2

```text
You are generating a test input inside a program-synthesis pipeline.
Object language: toml
Goal: an input whose execution reaches the error marker `array_table_missing_close_char`.

Z3 cannot search for this input: the lifted parser is too large to solve with a symbolic input. So the division of labour is inverted — YOU propose a concrete candidate, and Z3 DECIDES it by pinning it into the unmodified query. A candidate is accepted only when Z3 answers `sat`, which means the lifted semantics genuinely reach `array_table_missing_close_char` on that input.

Two things make a candidate fail, and both are reported back to you:
* `unsat` — the input does not reach `array_table_missing_close_char`. Usually it reaches a DIFFERENT error first (an earlier syntax error shadows the one you want), or it is simply valid.
* `unknown`/timeout — rare for a pinned input; treat as a hint to simplify.

== The channel (a contract, not advice) ==
A control character cannot reach us as a raw byte. Spell it `\u{XX}` — e.g. `\u{0}` for NUL, `\u{7f}` for DEL. That is the ONLY escape decoded; every other backslash is passed through verbatim, so a TOML escape such as `\q` or `\uZZZZ` reaches the parser exactly as you wrote it.

== A domain prior (hints only; ignore any that do not fit) ==
These shape where you look. They decide nothing: acceptance is Z3's alone.
* Only the FIRST error matters — the parser stops there, so everything before the intended violation must be valid or it will shadow it.
* Shorter is better: extra keys, tables and whitespace add chances to trip an earlier rule.
* The marker name states the rule. Violate exactly that and nothing else.

== The emitted SMT-LIB for this marker (truncated) ==
(set-option :print-success false)
(set-option :produce-models true)
(set-option :produce-proofs false)
(set-option :produce-unsat-cores false)
(set-option :sat.random_seed 42)
(set-option :smt.random_seed 42)

(set-option :sat.restart.max 100000)
(set-option :smt.arith.solver 6)
(set-option :smt.case_split 3)
(set-option :smt.phase_selection 3)
(set-option :smt.mbqi true)
(set-option :smt.qi.eager_threshold 10.0)
(set-option :smt.qi.max_multi_patterns 1000)
(set-option :smt.ematching true)
(set-option :smt.auto_config false)

(declare-datatypes ((RuSmtSet 1)) ((par (T) ((mk-rset (rset-data (Array T Bool)) (rset-card Int))))))
(declare-datatypes ((RuSmtArray 2)) ((par (K V) ((mk-rarr (rarr-da
; … 216260 bytes of parser definitions elided …
Ok_2_ (parse_newline state)))))) (field_ParseResult_Ok_2_ (parse_expression (field_ParseResult_Ok_2_ (parse_newline state)))))))))))))
(define-fun parse_toml_inner ((state State)) (ParseResult Value) (ite (is-ParseResult_Err (parse_expression state)) ((as ParseResult_Err (ParseResult Value)) (field_ParseResult_Err_1_ (parse_expression state))) (ite (is-ParseResult_NoMatch (parse_expression state)) (as ParseResult_NoMatch (ParseResult Value)) (ite (is-Optional_None (current_char (field_ParseResult_Ok_2_ (parse_expression state)))) ((as ParseResult_Ok (ParseResult Value)) ((as Value_Table Value) (field_ParseResult_Ok_1_ (parse_expression state))) (field_ParseResult_Ok_2_ (parse_expression state))) (parse_toml_loop (field_ParseResult_Ok_1_ (parse_expression state)) (field_ParseResult_Ok_2_ (parse_expression state)))))))
(define-fun parse_toml ((input (Seq (_ BitVec 32)))) (ParseResult Value) (parse_toml_inner (mk-State default_parser_context 0 input)))

; Base SMT-LIB definitions complete
; Add error-specific assertions below


(declare-const input_0 (Seq (_ BitVec 32)))
(assert (forall ((__i Int)) (=> (and (>= __i 0) (< __i (seq.len input_0))) (let ((__c (seq.nth input_0 __i))) (or (bvule __c #x0000D7FF) (and (bvuge __c #x0000E000) (bvule __c #x0002FFFF)))))))(assert (and (is-ParseResult_Err (parse_toml input_0)) (= (bvand (field_ParseResult_Err_1_ (parse_toml input_0)) (_ bv1125899906842624 183)) (_ bv1125899906842624 183))))
(check-sat)
(get-info :reason-unknown)
(get-model)


== Candidates already rejected ==
--- attempt 1 ---
[[a
--- Z3 said ---
`unsat`: this input does not reach `array_table_missing_close_char`. Z3 reports that it reaches ERR array_table_missing_close_eof instead — a DIFFERENT rule fired first and shadowed the one you want. Fix that earlier violation so the document is valid up to the point `array_table_missing_close_char` is about.

Reply with the candidate input between <<< and >>> and nothing else:
input <<<
(your candidate here)
>>>

===RESPONSE===
<<<[[a]x>>>
```
