# Draft 3 build and visual checks

- Native Beamer talk, handout review and speaker guide built with pdflatex.
- 38 timed main frames, 11 extra overlay states, 10 backups.
- Live deck: 59 pages, main talk through page 49. Review: 48 pages.
- Speaker guide: 25 pages; allocations sum to 1200 seconds.
- New main frames 22–31 and backup B10 rendered and inspected at presentation size.
- All review pages rendered into contact sheets. Additional Poppler renders
  checked the raw candidate delimiters and exact runner flags.
- Literal <<< and >>> use separate character boxes to prevent TeX ligatures;
  the two-hyphen runner flag is likewise kept literal.
- No overfull-box or missing-glyph warnings in the final slide or notes build.
  A nonfatal underfull warning on the miss chart and a hyperref bookmark warning
  remain; neither corresponds to clipped slide content.
- The new frames' extracted text boxes are within page bounds.
- Unchanged main-frame bodies were compared against Draft 2, excluding footers.
- No model calls, specification changes or experimental reruns were performed.

## Body comparison (old frame, new frame, fraction of raster bytes different)

- 1, 1, 0.0
- 2, 2, 0.0
- 3, 3, 0.0
- 4, 4, 0.0
- 5, 5, 0.0
- 6, 6, 0.0
- 7, 7, 0.0
- 8, 8, 0.0
- 9, 9, 0.0
- 10, 10, 0.0
- 11, 11, 0.0
- 12, 12, 0.0
- 13, 13, 0.0
- 14, 14, 0.0
- 15, 15, 0.0
- 16, 16, 0.0
- 17, 17, 0.0
- 18, 18, 0.0
- 19, 19, 0.0
- 20, 20, 0.0
- 21, 21, 0.0
- 30, 32, 0.0
- 31, 33, 0.0
- 32, 34, 0.0
- 33, 35, 0.0
- 34, 36, 0.0
- 35, 37, 0.0
- 36, 38, 0.0
