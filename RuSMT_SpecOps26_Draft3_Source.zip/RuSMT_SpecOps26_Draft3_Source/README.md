# RuSMT — SpecOps ’26 — Draft 3

Presenter: Meng Xu. Coauthor: Mehrad Haghshenas.

Native LaTeX Beamer, 16:9, with editable TikZ diagrams and code panels.
38 main frames, 11 extra overlay states (49 live main pages), and 10 backup
frames. The static review has 48 pages; the complete live deck has 59.
The timed narration allocates exactly 20:00, including overlays and without Q&A.
Timings are rehearsal targets, not measured speaking times.

## Build

Use a standard TeX Live or MiKTeX distribution with Beamer, TikZ/PGF, TeX Gyre
Heros (`tgheros`), Inconsolata, and the other normal packages named in `theme.tex`.
No font binaries, raster figures, shell escape, model calls, or solver runs
are required. Python 3 (standard library only) builds the page map and guide.

```sh
make                 # live deck, static review, and speaker guide
make slides          # build/rusmt-talk.pdf
make review          # build/rusmt-review.pdf
make notes           # build/speaker-guide.pdf
make clean
```

Main entry: `rusmt-talk.tex`. Review mode: `rusmt-review.tex`.
All frames contain Beamer speaker notes. The provided guide is an independent
printable view with static thumbnails, times, delivery cues, and precision notes.

## Editing

- `sections/main.tex` and `sections/backup.tex`: directly editable frame source.
- `figures/diagrams.tex` and `figures/code-excerpts.tex`: shared TikZ and code panels.
- `theme.tex`: typography, marker accent, stable-overlay helpers, and literal
  angle-bracket protocol delimiters.
- `slide-plan.json`: matching structured bodies, speaker text, and timing plan.
- `scripts/build-frames.py`: optional regeneration from the JSON plan. It
  overwrites the section files and regenerates `speaker-notes.md`; it is not
  implicitly run by `make`, so direct LaTeX edits are preserved.
- `scripts/build-page-map.py`: maps logical frames to actual live PDF pages.
- `scripts/build-speaker-guide.py`: creates the printable guide from the plan.

When changing frame content, keep the JSON plan and direct TeX source in sync
if both will be edited. After changing overlays or frame counts, run `make`
so the live page map and speaker guide are regenerated.

## Draft 3 focus

Frames 22–27 replace the abstract LLM sequence with the runner interface, prompt
components, raw candidate format, separate target and diagnostic checks,
updated retry prompt, and replay. Frames 28–31 connect the fixed nine-round
budget to coverage and expose the miss and rejection categories. Backup B10
records implementation-level runner and transport details.

The exact two cached bracket-example prompts and final responses are under
`examples/llm-bracket-round-1.txt` and `examples/llm-bracket-round-2.txt`.
See `examples/LLM_PROVENANCE.md` for their origin and slide transformations.
The source scripts stored under `examples/` are for inspection; the deck
build never runs them.

## Sources and interpretation

The accepted `rusmart-paper.pdf`, especially §§3.3, 4, 6 and 8, supplies the
experimental claims and numbers. The code archive illustrates prompt wording,
serialization, and the runner. The Regorus origin is author-supplied motivation.
Prompt excerpts are labeled as condensed, and the exact recorded replies are
distinguished from the conceptual solver model.

The paper reports no acceptance-check timeouts. Neither the misses nor the
rejections are attributed to prompt truncation, low reasoning effort, or model
size: there is no reported ablation establishing those causes. The misses are
unresolved targets, and rejected candidates commonly reach a different marker.

No Rego specification, generation run, or solver/model ablation is claimed.
