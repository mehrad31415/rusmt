# Draft 3 — LLM interface and interpretation of results

## Changes from Draft 2

| Draft 3 frames | Change |
|---|---|
| 22 | Names Codex CLI and gpt-5.4-mini; distinguishes the candidate subprocess from the RuSMT-controlled checking/retry loop. |
| 23 | Groups the prompt into task, SMT-LIB context, rejected-history feedback, and hints/output contract. |
| 24 | Shows the actual first response delimiter format and its extraction into a concrete document; distinguishes candidate input from a Z3 model. |
| 25 | Separates the target check from the second diagnostic query, using the same fixed input. |
| 26 | Shows how the next prompt incorporates the failed attempt and observed EOF marker, then reveals the exact second response. |
| 27 | Retains target checking and concrete replay without a separate repeated invariant slide. |
| 28 | Shows one requested witness, up to nine rounds, 2 s/20 s Z3 budgets, 146/183 coverage, and selected cumulative-round values. |
| 29 | Promotes the 20/10/6/1 unresolved-marker breakdown into the main talk. |
| 30 | Separates 146 accepted and 442 rejected target checks from 28 repeats and 19 replies with no parsable candidate. |
| 31 | Connects the 88.2% wrong-marker diagnosis to first-error masking, including the fact that the prompt already warns about it. |
| B10 | Adds exact runner configuration and archive-level transport details as backup. |

The prior opening, IMP code walkthrough, and TOML parser-branch code are unchanged
in substance. Downstream findings and conclusions remain unchanged in substance.

## Pacing

38 main frames + 11 extra overlay states = 49 main presentation PDF pages.
10 backup frames follow (pages 50–59); the review has 48 total pages.
The updated speaker plan still totals 20:00, with no Q&A allowance.
Frames 22–27 occupy 10:55–14:05; frames 28–31 occupy 14:05–15:55.
The origin story and repeated summaries receive modestly shorter allocations.

## What the evidence does and does not explain

The paper supplies a fixed search budget and an observed distribution of misses.
It identifies earlier-error masking and long numeric/temporal parser chains as
consistent with the observed pattern. It reports 442 unsatisfiable candidate
checks, predominantly reaching another marker. These observations do not
isolate the causal effect of prompt length, model choice, reasoning effort, or
round count. The paper reports no acceptance-check timeouts; they are not used
as an explanation for the 37 misses.

The archive is used for concrete prompt/response illustrations, not to replace
the accepted paper's experimental accounting. The source package includes the
full cached two-round exchange.
