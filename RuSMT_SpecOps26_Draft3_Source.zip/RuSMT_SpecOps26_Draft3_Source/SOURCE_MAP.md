# Draft 2 source map

## Authority

The accepted `rusmart-paper.pdf` is the authority for the method, guarantees,
terminology, and empirical results. Printed section references in slide footers
refer to that paper. The attached `rusmt-code-spec_ops_26.zip` supplies illustrative
source excerpts only. This revision does not reconcile or substitute different
artifact results for those in the accepted paper.

The brief research-origin account comes from Meng Xu in this conversation. It is
not attributed to the paper. The public Regorus repository, consulted on
2026-10-06, identifies the project as Microsoft’s Rego interpreter in Rust:
https://github.com/microsoft/regorus . No current release, conformance level, or
performance claim is imported from that repository.

## New material

| Frame | Basis | What was omitted or reformatted |
|---|---|---|
| 2 | Paper §1 | A new diagram of the same-input conformance setup; not a claim that IMP was differentially evaluated. |
| 3 | Author-provided origin; Regorus README | Rego syntax and implementation details are omitted. Scope explicitly excludes a Rego evaluation. |
| 7 | `lang/src/imp/ast.rs`, `Aexp` and `Com`; paper §2 and §5.1 | Imports, comments, and irrelevant variants are omitted with visible comments. `Div` is line-wrapped. The 1,084-line count comes from the paper. |
| 8 | `lang/src/imp/mod.rs`, `EvalResult` and `eval_com`; paper §3.1 | Comments/imports omitted; the function signature is line-wrapped. Types, constructors, fixed empty-store creation, and call are retained. |
| 9 | `lang/src/imp/mod.rs`, `eval_com_inner`, `Com::Assign` arm | Other match arms and the outer function are omitted. The `Ok` arm is line-wrapped. Actual calls and returned results are retained. |
| 10 | Paper §2, Listing 1 | The displayed code follows the accepted paper’s listing, including its compact `Path::named` argument. Only emphasis changes between overlays. |
| 11 | `lang/src/imp/mod.rs`, `store_get`; paper §6 witness | Function signature and comments are omitted; its body is retained with a line break in the nested returned error. The artifact’s `String::from` conversion is retained. |
| 12 | `Aexp`, `Com`, `eval_com`, `eval_com_inner`, and `eval_aexp` in the IMP source | The AST picture omits namespaces, `I64::from`, and `Cloak` wrappers; it is labeled a sketch, not compilable source. Call names and error propagation reflect the source. |
| 13–15 | Paper §§2–4 and §6 | Visuals explain fixed interpreter/state, symbolic AST, rendered witness, and concrete replay. Times and example programs come from the paper. |
| 18 | `lang/src/toml/table.rs`, `parse_array_table`, lines 133–156; close helper at lines 198–222 | Outer opening/key logic omitted. Arms are line-wrapped and redundant arm braces are elided. The inner `NoMatch` branches are explicitly deferred to the next frame. |
| 19 | Same `NoMatch` branch, lines 138–153; paper §3.3 | Arm braces and trailing argument commas are elided for layout; the return expressions, constructor names, marker names, and saved state remain unchanged. The vertical bar annotates the saved cursor and is not input text. |

The excerpt files in `examples/` contain the original source ranges, with comments
and formatting intact, for comparison. They are not complete Rust programs.

## Existing result frames, renumbered

Frames 16–17 and 20–26: paper §3.2, §3.3, §4, and §5.2. The 16-character probe is a
single reported experiment, not an average. The candidate exchange is the paper’s
worked example.

Frames 27–34: paper §6, Tables 2–4. Coverage, proposal counts, rejection
classification, parser comparisons, issue triage, the generated and minimized
witnesses, and the allowed integer-width difference all follow the accepted paper.
The illustration of the five existing corpus cases is schematic, not copied
corpus contents.

Frames 35–36 and backups: paper §§2–4 and §§6–9. The formalization remains trusted;
coverage is marker-relative; unresolved markers are not unreachable by inference.


## Draft 3 additions: frames 22–31 and B10

Paper §3.3 is the basis for prompt inputs, pinning, the second diagnostic query,
and the [[a / [[a]x exchange. Paper §4 supplies replay acceptance. Paper §6
supplies the Codex runner/model, budgets, round table, 146/183 coverage, 37-miss
categories, 146/442 target-check accounting, 28 duplicate and 19 unparseable
responses, and 88.2/5.9/5.9 diagnostic percentages. Paper §8 supplies the
unresolved-versus-unreachable interpretation.

The exact cached prompt and response examples and runner implementation are
listed in `examples/LLM_PROVENANCE.md`. The displayed prompt is condensed, with
the solver body collapsed and feedback shortened. Raw returned candidates are
not rephrased. No newly run generation results or model ablations are asserted.
