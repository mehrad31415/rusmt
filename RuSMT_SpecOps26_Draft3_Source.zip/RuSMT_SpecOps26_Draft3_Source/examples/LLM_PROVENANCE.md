# LLM-segment source provenance

The accepted PDF, sections 3.3, 4, 6 and 8, supplies the experimental claims.
The following archive files illustrate prompt wording, serialization, and invocation.
They do not replace paper-reported metrics. No model or solver was rerun to make this deck.

- `llm-bracket-round-1.txt`: exact cached first prompt and final response, archive
  `artifact/llm-cache/e5311747d3cab382cc467469d8497f99-4085.txt`.
- `llm-bracket-round-2.txt`: exact cached second prompt and final response, archive
  `artifact/llm-cache/2688e11c15e47b158b1ff3bff52bbcc4-4471.txt`.
- `llm-bracket-transcript.txt`: `artifact/run/toml/z3_chc/target_164/cosolve.txt`.
- `llm-prompt-and-response-original.rs`: `smt/derive/src/cosolve.rs`; see
  `build_certify_prompt`, `parse_proposal`, `decode_escapes`, and `certify`.
- `llm-transport-original.rs`: `smt/derive/src/proposer.rs`; see `CommandProposer::invoke`
  and the explicit prompt/response cache.
- `experiment-1-runner-original.sh`: `specops/run-experiment-1.sh`, preserved for
  inspection only. It is not executed by the slide build.

## Slide transformations

Frame 23 groups the prompt into four fields. Its hints are condensed from the
recorded prompt. Frame 24 reproduces the first response exactly (line breaks
included). Frame 25 summarizes the two solver queries and shortens the feedback.
Frame 26 shows a condensed field-level reconstruction of the second prompt, not
a literal transcript; its returned candidate is exact. The recorded prompt
labels its SMT-LIB section as truncated; the Rust parser source is not part of
that prompt. The solver checks the complete original query with an equality
fixing the input.

## Claim boundaries

The recorded configuration and missing-marker categories do not identify the
causal contribution of prompt length, model size, reasoning effort, or the
nine-round cap. The paper reports no pinned acceptance-check timeouts; this
deck does not attribute the 37 misses to such timeouts. The model's final text
replies are recorded, but the available record is not a complete agent tool trace.
The separate unevaluated specification-authoring mode is not this test-input loop.
