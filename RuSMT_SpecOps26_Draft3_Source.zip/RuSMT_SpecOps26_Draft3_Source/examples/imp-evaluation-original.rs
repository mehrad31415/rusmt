// Original illustrative source ranges, not a standalone compilation unit.
// Source: lang/src/imp/mod.rs

// Original lines 19–24
#[smt_type]
pub enum EvalResult {
    /// A path-condition marker fired (division by zero or undefined variable).
    Err(Path),
    /// Normal termination with the final store.
    Ok(Array<String, I64>),

// Original lines 54–63
/// Read a location from the store. Returns an error if the location is not found.
#[smt_fn]
pub fn store_get(s: Array<String, I64>, x: String) -> StoreGetResult {
    if *s.contains_key(x) {
        StoreGetResult::Ok(s.select(x))
    } else {
        // Named marker: reading a variable absent from the store is an error.
        StoreGetResult::Err(Path::named(String::from("undefined_variable")))
    }
}

// Original lines 69–116
/// each carries a fresh path-condition marker.
#[smt_fn]
pub fn eval_aexp(a: Aexp, s: Array<String, I64>) -> ArithmeticResult {
    match a {
        Aexp::Num(n) => ArithmeticResult::Ok(n),
        Aexp::Var(x) => match store_get(s, x) {
            StoreGetResult::Err(e) => ArithmeticResult::Err(e),
            StoreGetResult::Ok(v) => ArithmeticResult::Ok(v),
        },
        Aexp::Add(l, r) => match eval_aexp(l.reveal(), s) {
            ArithmeticResult::Err(e) => ArithmeticResult::Err(e),
            ArithmeticResult::Ok(new_l) => match eval_aexp(r.reveal(), s) {
                ArithmeticResult::Err(e) => ArithmeticResult::Err(e),
                ArithmeticResult::Ok(new_r) => ArithmeticResult::Ok(new_l.bv_add(new_r)),
            },
        },
        Aexp::Sub(l, r) => match eval_aexp(l.reveal(), s) {
            ArithmeticResult::Err(e) => ArithmeticResult::Err(e),
            ArithmeticResult::Ok(new_l) => match eval_aexp(r.reveal(), s) {
                ArithmeticResult::Err(e) => ArithmeticResult::Err(e),
                ArithmeticResult::Ok(new_r) => ArithmeticResult::Ok(new_l.bv_sub(new_r)),
            },
        },
        Aexp::Mul(l, r) => match eval_aexp(l.reveal(), s) {
            ArithmeticResult::Err(e) => ArithmeticResult::Err(e),
            ArithmeticResult::Ok(new_l) => match eval_aexp(r.reveal(), s) {
                ArithmeticResult::Err(e) => ArithmeticResult::Err(e),
                ArithmeticResult::Ok(new_r) => ArithmeticResult::Ok(new_l.bv_mul(new_r)),
            },
        },
        Aexp::Div(l, r) => match eval_aexp(l.reveal(), s) {
            ArithmeticResult::Err(e) => ArithmeticResult::Err(e),
            ArithmeticResult::Ok(new_l) => match eval_aexp(r.reveal(), s) {
                ArithmeticResult::Err(e) => ArithmeticResult::Err(e),
                ArithmeticResult::Ok(new_r) => {
                    if *new_r.eq(I64::from(0)) {
                        // Named marker: division by a zero divisor is an error.
                        ArithmeticResult::Err(Path::named(String::from("division_by_zero")))
                    } else {
                        ArithmeticResult::Ok(new_l.bv_div(new_r))
                    }
                }
            },
        },
    }
}

/// Big-step evaluation of boolean expressions.

// Original lines 160–183
/// Big-step evaluation of commands.
#[smt_fn]
pub fn eval_com(c: Com) -> EvalResult {
    let s = Array::new();
    eval_com_inner(c, s)
}

/// Inner function for big-step evaluation of commands.
#[smt_fn]
pub fn eval_com_inner(c: Com, s: Array<String, I64>) -> EvalResult {
    match c {
        Com::Skip => EvalResult::Ok(s),
        Com::Assign(x, a) => {
            let v = eval_aexp(a.reveal(), s);
            match v {
                ArithmeticResult::Err(e) => EvalResult::Err(e),
                ArithmeticResult::Ok(new_v) => EvalResult::Ok(s.store(x, new_v)),
            }
        }
        Com::Seq(c0, c1) => match eval_com_inner(c0.reveal(), s) {
            EvalResult::Err(e) => EvalResult::Err(e), // propagate error
            EvalResult::Ok(s1) => eval_com_inner(c1.reveal(), s1),
        },
        Com::If(b, c0, c1) => match eval_bexp(b.reveal(), s) {
