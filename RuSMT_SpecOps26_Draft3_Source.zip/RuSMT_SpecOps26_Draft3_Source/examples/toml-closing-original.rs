// Original illustrative source ranges, not a standalone compilation unit.
// Source: lang/src/toml/table.rs

// Original lines 110–163

/// `array-table = array-table-open key array-table-close`
#[smt_fn]
pub(crate) fn parse_array_table(state: State) -> ParseResult<Seq<String>> {
    match parse_array_table_open(state) {
        ParseResult::Ok(_open_brackets, state_after_open) => {
            match current_char(state_after_open) {
                Optional::None => {
                    // println!("cannot have [[");
                    ParseResult::Err(Path::named(String::from("array_table_open_eof")))
                } // cannot have [[
                Optional::Some(x) => {
                    if *x.eq(U32::from(0x5D)) {
                        // empty table name
                        {
                            // println!("cannot have empty table name");
                            return ParseResult::Err(Path::named(String::from(
                                "array_table_empty_name",
                            )));
                        }
                    } else {
                        // non-empty table name
                        match parse_key(state_after_open) {
                            ParseResult::Ok(key, state_after_key) => {
                                match parse_array_table_close(state_after_key) {
                                    ParseResult::Ok(_close_brackets, state_after_close) => {
                                        return ParseResult::Ok(key, state_after_close);
                                    }
                                    ParseResult::NoMatch => match current_char(state_after_key) {
                                        Optional::Some(_ch) => {
                                            // found another character where ]] expected
                                            // println!("found another character where ]] expected");
                                            return ParseResult::Err(Path::named(String::from(
                                                "array_table_missing_close_char",
                                            )));
                                        }
                                        Optional::None => {
                                            // reached end of input where ]] expected
                                            // println!("reached end of input where ]] expected");
                                            return ParseResult::Err(Path::named(String::from(
                                                "array_table_missing_close_eof",
                                            )));
                                        }
                                    },
                                    ParseResult::Err(e) => return ParseResult::Err(e), // cannot happen
                                }
                            }
                            ParseResult::NoMatch => return ParseResult::NoMatch, // cannot happen
                            ParseResult::Err(e) => return ParseResult::Err(e),
                        }
                    }
                }
            }
        }

// Original lines 197–225
#[smt_fn]
fn parse_array_table_close(state: State) -> ParseResult<String> {
    let state_after_ws = parse_ws(state);
    match current_char(state_after_ws) {
        Optional::Some(ch1) => {
            if *ch1.eq(U32::from(0x5D)) {
                let next_state = advance(state_after_ws);
                match current_char(next_state) {
                    Optional::Some(ch2) => {
                        if *ch2.eq(U32::from(0x5D)) {
                            let next_next_state = advance(next_state);
                            let res = cp_to_str(ch1).concat(cp_to_str(ch2));
                            ParseResult::Ok(res, next_next_state)
                        } else {
                            ParseResult::NoMatch
                        }
                    }
                    Optional::None => ParseResult::NoMatch,
                }
            } else {
                ParseResult::NoMatch
            }
        }
        Optional::None => ParseResult::NoMatch,
    }
}

/// Re-scope a state's context to `path`: an inline table's body defines keys and
/// sub-tables of the inline table itself, so it is parsed under its own path.
