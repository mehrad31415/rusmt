#!/usr/bin/env python3
"""Regenerate TeX frames and Markdown notes from slide-plan.json.
This overwrites sections/main.tex and sections/backup.tex; it is not part of make.
"""
from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
F=json.loads((R/'slide-plan.json').read_text())
N=sum(not f['backup'] for f in F)
def safe_note(t):
    table={'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}
    return ''.join(table.get(c,c) for c in t).replace('→',r'$\rightarrow$')
def frame(f):
    ident=f['id'] if f['backup'] else f"{f['id']} / {N}"
    return (f"% ---- FRAME {f['id']}: {f['title']} ----\n"
            +r'\FrameMeta{'+safe_note(f['section'])+'}{'+safe_note(f['source'])+'}{'+ident+'}\n'
            +r'\begin{frame}[t,label=f'+f['id']+']\n'
            +r'\frametitle{'+safe_note(f['title'])+'}\n'+f['body']+'\n'
            +r'\note{'+safe_note(f['narration'])+'}\n'+r'\end{frame}'+'\n\n')
for backup,filename in [(False,'main.tex'),(True,'backup.tex')]:
    (R/'sections'/filename).write_text('% Native Beamer source; directly editable. Draft 3.\n\n'+''.join(frame(f) for f in F if f['backup']==backup))
def clock(t):return f'{t//60:02}:{t%60:02}'
lines=['# RuSMT — SpecOps ’26, Draft 3: speaker notes',
       '\nPresenter: Meng Xu. Authors: Mehrad Haghshenas and Meng Xu.',
       f'\n{N} main frames; 20:00, including overlays; ten untimed backup frames.',
       '\nTimings are rehearsal targets, not measured speaking times.',
       '\nThe accepted paper is authoritative for technical claims and results. Code excerpts illustrate authoring and control flow. The Regorus origin is author-supplied context, not an evaluated case study.',
       '\n## Segment timing\n',
       '| Frames | Clock | Segment |\n|---|---|---|',
       '| 1–6 | 00:00–02:30 | Interpreter testing and the selected condition. |',
       '| 7–15 | 02:30–07:50 | Write and follow IMP; derive both uses. |',
       '| 16–21 | 07:50–10:55 | TOML branches and the solver limitation. |',
       '| 22–27 | 10:55–14:05 | Runner, prompt, candidate, feedback, and replay. |',
       '| 28–31 | 14:05–15:55 | Fixed-budget coverage, unresolved markers, and rejections. |',
       '| 32–36 | 15:55–18:35 | Conformance comparisons and triage. |',
       '| 37–38 | 18:35–20:00 | Boundaries and the shared-source takeaway. |' ]
for f in F:
    lines+=['\n## '+f['id']+' — '+f['title'],
            '\n'+('Backup: outside the timed talk.' if f['backup'] else f"{clock(f['start_seconds'])}–{clock(f['end_seconds'])} ({f['seconds']} seconds, including overlays)."),
            '\n'+f['narration'], '\n**Delivery:** '+f['cue'] if f['cue'] else '',
            '\n**Precision:** '+f['guardrail'] if f['guardrail'] else '', '\n**Source:** '+f['source']]
(R/'speaker-notes.md').write_text('\n'.join(lines)+'\n')
