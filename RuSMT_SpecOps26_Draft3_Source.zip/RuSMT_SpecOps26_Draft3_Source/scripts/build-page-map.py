#!/usr/bin/env python3
"""Record Beamer logical frames and their live/review PDF page numbers."""
from pathlib import Path
import json,re
R=Path(__file__).resolve().parents[1]
frames=json.loads((R/'slide-plan.json').read_text())
nav=(R/'build/rusmt-talk.nav').read_text()
pages=re.findall(r'\\beamer@framepages\s*\{(\d+)\}\s*\{(\d+)\}',nav)
if len(pages)!=len(frames):
    raise SystemExit(f'Expected {len(frames)} frame page records, found {len(pages)}. Rebuild slides first.')
records=[dict(frame=f['id'],title=f['title'],review_page=i+1,first_page=int(a),last_page=int(b),backup=f['backup']) for i,(f,(a,b)) in enumerate(zip(frames,pages))]
(R/'page-map.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
print(f'Mapped {len(records)} logical frames to {pages[-1][1]} live PDF pages.')
