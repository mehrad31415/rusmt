#!/usr/bin/env python3
"""Build an editable LaTeX rehearsal guide from slide-plan.json.

The guide embeds the static review PDF as vector thumbnails. It does not
recreate or rasterize the slides. Run from any directory; paths are resolved
relative to this source package. Standard-library Python only.
"""
from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def tex(text: str) -> str:
    substitutions = {
        '\\': r'\textbackslash{}', '&': r'\&', '%': r'\%', '$': r'\$',
        '#': r'\#', '_': r'\_', '{': r'\{', '}': r'\}',
        '~': r'\textasciitilde{}', '^': r'\textasciicircum{}',
    }
    text = ''.join(substitutions.get(c, c) for c in text)
    return (text.replace('’', "'").replace('‘', "'")
                .replace('“', '``').replace('”', "''")
                .replace('—', '---').replace('–', '--')
                .replace('→', r'$\rightarrow$').replace('<<<',r'\texttt{\textless{}\textless{}\textless{}}').replace('>>>',r'\texttt{\textgreater{}\textgreater{}\textgreater{}}'))

def clock(seconds: int) -> str:
    return f'{seconds // 60:02d}:{seconds % 60:02d}'

frames = json.loads((ROOT / 'slide-plan.json').read_text())
main = [f for f in frames if not f['backup']]
assert len(main) == 38 and sum(f['seconds'] for f in main) == 1200
words = sum(len(f['narration'].split()) for f in main)
page_map = json.loads((ROOT / 'page-map.json').read_text())
main_count = len(main)
backup_count = len(frames) - main_count
live_main_pages = max(p['last_page'] for p in page_map if not p['backup'])
overlay_count = live_main_pages - main_count
header = r'''\documentclass[10pt,a4paper]{article}
\usepackage[T1]{fontenc}
\usepackage[utf8]{inputenc}
\usepackage[margin=17mm,headheight=14pt]{geometry}
\usepackage{tgheros}
\usepackage[scaled=.95]{inconsolata}
\renewcommand{\familydefault}{\sfdefault}
\usepackage{xcolor,graphicx,array,booktabs,fancyhdr,lastpage,hyperref}
\definecolor{Ink}{HTML}{252D36}
\definecolor{Accent}{HTML}{007C78}
\definecolor{Muted}{HTML}{61707B}
\definecolor{Rule}{HTML}{DCE3E6}
\color{Ink}
\setlength{\parindent}{0pt}
\setlength{\parskip}{4pt}
\hypersetup{colorlinks=true,linkcolor=Accent,urlcolor=Accent,
 pdftitle={RuSMT | Speaker notes and 20-minute rehearsal plan},pdfauthor={Meng Xu; presentation draft}}
\pagestyle{fancy}
\fancyhf{}
\fancyhead[L]{\small\color{Muted}RuSMT / SPECOPS '26}
\fancyhead[R]{\small\color{Muted}SPEAKER NOTES / DRAFT 3}
\fancyfoot[L]{\small\color{Muted}Meng Xu}
\fancyfoot[R]{\small\color{Muted}\thepage\ /\ \pageref{LastPage}}
\renewcommand{\headrulewidth}{.3pt}
\renewcommand{\footrulewidth}{0pt}
\newcommand{\divider}{\par\par\vspace{4mm}{\color{Rule}\hrule}\vspace{5mm}}
\begin{document}
{\fontsize{28}{32}\selectfont\bfseries RuSMT\par}
{\fontsize{17}{22}\selectfont Speaker notes and rehearsal plan\par}
\par\vspace{3mm}
\textbf{Presenter:} Meng Xu\qquad\textbf{Coauthor:} Mehrad Haghshenas\\
University of Waterloo\qquad SpecOps '26
\divider
{\large\bfseries MAINCOUNT main frames / 20:00 / no planned Q\&A interval}\par
OVERLAYCOUNT additional overlay states are included in the frame timings. BACKUPCOUNT backup
frames are outside the timed talk. The live PDF contains LIVEMAINCOUNT main presentation
pages followed by the BACKUPCOUNT backups. The review PDF contains one final state
per logical frame.

The allocations are rehearsal targets, not measured speaking times. The
suggested narration contains WORDCOUNT words; pointing, pauses, and overlay
changes are additional parts of delivery. Keep the condition-specific question
visible through the IMP example, the TOML exchange, and the results.
\par\vspace{3mm}
\textbf{The story}\par
Test a language implementation. Write a reference semantics and name selected
conditions inside it. Derive the tests and oracle from that same source. IMP
shows the authoring experience; TOML carries the empirical story.
\par\vspace{3mm}
\renewcommand{\arraystretch}{1.45}
\begin{tabular}{@{}llp{10.4cm}@{}}
\toprule
\textbf{Frames} & \textbf{Clock} & \textbf{Segment}\\
\midrule
1--6 & 00:00--02:30 & Interpreter testing and the selected condition\\
7--15 & 02:30--07:50 & Write and follow IMP; derive both uses\\
16--21 & 07:50--10:55 & TOML branches and the solver limitation\\
22--27 & 10:55--14:05 & Runner, prompt, candidate, feedback, and replay\\
28--31 & 14:05--15:55 & Fixed-budget coverage, misses, and rejections\\
32--36 & 15:55--18:35 & Conformance comparisons and triage\\
37--38 & 18:35--20:00 & Boundaries and the central takeaway\\
\bottomrule
\end{tabular}\par
\par\vspace{4mm}
\textbf{Two distinctions to preserve}\par
``Rejected by the oracle'' is a document outcome. ``Target reached'' is the
outcome of the testing request. A successful error-targeting test is supposed
to be rejected by the oracle. Also, the paper's ``errors as values'' discipline
is not a totality or panic-freedom guarantee.
\par\vspace{3mm}
\textbf{Source authority}\par
The accepted paper is the basis for the technical claims, figures, and
experimental results. Code-archive differences are not used to alter its
claims. The code archive illustrates authoring and control flow. The Regorus
origin is author-provided motivation, not an evaluated case study. All illustrations not copied as examples from the paper are marked
as illustrations or schematics in the slides or notes. Paper DOI:
\href{https://doi.org/10.1145/3842652.3843196}{10.1145/3842652.3843196}.
\clearpage
'''.replace('WORDCOUNT', str(words)).replace('LIVEMAINCOUNT', str(live_main_pages)).replace('MAINCOUNT', str(main_count)).replace('OVERLAYCOUNT', str(overlay_count)).replace('BACKUPCOUNT', str(backup_count))
parts = [header]
page_map = json.loads((ROOT / 'page-map.json').read_text())
for i, f in enumerate(frames):
    # Two frame records per page. Backups begin on their own page.
    if i == main_count:
        parts.append(r'{\large\bfseries Backup frames: outside the 20-minute talk}\par\par\vspace{4mm}')
    timing = ('Outside the timed talk' if f['backup'] else
              f"{clock(f['start_seconds'])}–{clock(f['end_seconds'])} · {f['seconds']} seconds, including overlays")
    parts.append(r'{\color{Accent}\fontsize{13}{16}\selectfont\bfseries '+tex(f["id"]+' / '+f['title'])+r'\par}')
    parts.append(r'{\small\color{Muted}'+tex(timing)+r'\par}')
    pm = page_map[i]
    live = str(pm['first_page']) if pm['first_page'] == pm['last_page'] else f"{pm['first_page']}-{pm['last_page']}"
    parts.append(r'{\fontsize{8}{10}\selectfont\color{Muted}'+tex(f"Review page {i+1}; live PDF page(s) {live}.")+r'\par}\vspace{2mm}')
    parts.append(r'\begin{minipage}[t]{.325\textwidth}\vspace{0pt}')
    parts.append(r'\setlength{\fboxsep}{0pt}\color{Rule}\fbox{\includegraphics[page='+str(i+1)+r',width=.985\linewidth]{build/rusmt-review.pdf}}\par')
    parts.append(r'\vspace{2mm}{\raggedright\fontsize{8}{10.5}\selectfont\color{Muted}'+tex(f['source'])+r'\par}')
    parts.append(r'\end{minipage}\hfill\begin{minipage}[t]{.64\textwidth}\vspace{0pt}')
    parts.append(r'{\fontsize{10}{13}\selectfont '+tex(f['narration'])+r'\par}')
    parts.append(r'\end{minipage}\par')
    if f['cue']:
        parts.append(r'\vspace{2mm}{\fontsize{9}{11.5}\selectfont\textbf{Delivery:} '+tex(f['cue'])+r'\par}')
    if f['guardrail']:
        parts.append(r'{\fontsize{9}{11.5}\selectfont\textbf{Precision:} '+tex(f['guardrail'])+r'\par}')
    if (i < main_count and (i+1) % 2 == 0) or (i >= main_count and (i-main_count+1) % 2 == 0):
        parts.append(r'\clearpage')
    elif i < len(frames)-1:
        parts.append(r'\divider')
parts.append(r'\end{document}')
(ROOT / 'speaker-guide.tex').write_text('\n'.join(parts))
print(f'Wrote speaker-guide.tex: {len(main)} main, {len(frames)-len(main)} backup frames; {words} narration words.')
